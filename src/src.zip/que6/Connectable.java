package que6;

public interface Connectable {

	void connect();
	void disconnect();
	
}
