package que6;

public abstract class NetworkDevice implements Connectable {

	
}
