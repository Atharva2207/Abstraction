package que6;

public class Main {

	public static void main(String[] args) {
		
		Router myRouter =  new Router();
		
		myRouter.connect();
		myRouter.disconnect();
	}
}
