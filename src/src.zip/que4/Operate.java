package que4;

public interface Operate {

	public void start();
}
