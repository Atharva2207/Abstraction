package que4;

public abstract class Appliance {
	
	public void start() {
		System.out.println("Start  the appliances");
	}

}
