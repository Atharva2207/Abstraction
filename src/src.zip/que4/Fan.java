package que4;

public class Fan extends Appliance implements Operate {

	@Override
	public void start() {
		super.start();
		System.out.println("Fan is off");
	}
	
	

	
	

}
