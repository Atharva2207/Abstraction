package que1;

public class Main {

	public static void main(String[] args) {
		Robot R = new Robot();
		
		R.startEngine();
		R.drive();
		R.shutDown();
	}
}
