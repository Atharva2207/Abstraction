package que1;

public abstract class Machine implements Driveable {
	
	public abstract void drive();
	public abstract void shutDown();

}
