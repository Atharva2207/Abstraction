package que1;

public class Robot extends Machine {

	@Override
	public void drive() {
		System.out.println("Robot is driving");
	}

	@Override
	public void shutDown() {
		System.out.println("Robot is Shutting Down");
	}
	
	

}
