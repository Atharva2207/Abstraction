package que2;

public class Main {

	public static void main(String[] args) {
		RobotWork r = new RobotWork();
		r.dailyRoutine();
	}
}
