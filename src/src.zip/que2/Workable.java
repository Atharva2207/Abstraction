package que2;

public interface Workable {

	void work();
}
