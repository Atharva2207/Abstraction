package que2;

public interface Rechargeable {

	void recharge();
	}
