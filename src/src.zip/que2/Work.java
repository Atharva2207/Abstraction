package que2;

public abstract class Work implements Workable, Rechargeable {

	public abstract void dailyRoutine();
}
