package que3;

public class Main {
	public static void main(String[] args) {
		
		Laptop l = new Laptop();
		Smartphone s = new Smartphone();
		
		l.turnOff();
		l.turnOn();
		s.turnOn();
		s.turnOff();
	}

}
