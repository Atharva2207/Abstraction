package que3;

public class Smartphone extends ElectronicDevice {
	
	

	@Override
	public boolean turnOff() {
		System.out.println("Device is turn off");
		return false;
	}

}
