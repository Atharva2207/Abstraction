package que3;

public interface Device {

	boolean turnOn();
	boolean turnOff();
	
}
