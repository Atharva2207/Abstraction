package que5;

public class Main {
	
	public static void main(String[] args) {
		
		GamingComputer myGamingPC = new GamingComputer();
		myGamingPC.upgrade();
		myGamingPC.runDiagnostics();
	}

}
