package que5;

public interface Upgradeable {

	public void upgrade();
}
