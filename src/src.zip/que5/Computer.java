package que5;

public abstract class Computer implements Upgradeable {
	
	public abstract void runDiagnostics();

	
}
